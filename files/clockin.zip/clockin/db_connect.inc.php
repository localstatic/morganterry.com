<?php
   $db = mysql_connect("localhost", "work", "work");
   if( !$db )
   {
      die("Error connecting to the Server");
      exit;
   }
   $result = mysql_select_db("clockin", $db);
   if( !$result )
   {
      die("Error selecting Database");
      exit;
   }
?>

<?php

function clock_in($uid = 0)
{
	global $db;

	if (is_clocked_in())
	{
		return;
	}

	$timestamp = time();

	$sql = "INSERT INTO in_out (user_id, time_in) VALUES ($uid, $timestamp)";
	
	if (mysql_query($sql, $db))
		return true;
	else
		return false;
}

function clock_out($uid = 0)
{
	global $db;

	if (!is_clocked_in())
	{
		return;
	}

	$timestamp = time();

	$sql = "UPDATE in_out SET time_out = $timestamp WHERE time_out = 0 AND user_id = $uid";

	if (mysql_query($sql, $db))
		return true;
	else
		return false;
}

function is_clocked_in($uid = 0)
{
	$active_record = get_active_record($uid);

	if (NULL != $active_record)
		return true;
	else
		return false;
}

function get_active_record($uid)
{
	global $db;

	$sql = "SELECT * FROM in_out WHERE time_out = 0 AND user_id = $uid";

	$rs = mysql_query($sql, $db);

	if ($rs && mysql_num_rows($rs) > 0)
	{
		return mysql_fetch_array($rs);
	}
	else
	{
		return NULL;
	}
}

function get_time_data($start_dt, $end_dt = 0, $uid = 0)
{
	global $db;

	$sql = "SELECT * FROM in_out WHERE time_in >= $start_dt AND user_id = $uid";

	if ($end_dt != 0)
	{
		$sql .= " AND time_out <= $end_dt AND time_out <> 0";
	}

	$sql .= " ORDER BY time_in, time_out";

	$time_data = array();

	$rs = mysql_query($sql, $db);

	if ($rs && mysql_num_rows($rs) > 0)
	{
		while ($rec = mysql_fetch_array($rs))
		{
			$time_data[] = array('id'  => $rec['id'],
			                     'in'  => $rec['time_in'],
					     'out' => $rec['time_out']);
		}
	}

	return $time_data;
}

function get_time_data_html($time_data)
{
	$html = '';

	if (count($time_data) > 0)
	{
		$html .= "<table>\n";
		$html .= "<tr><th>In</th><th>Out</th><th>Length</th></tr>\n";

		$total_seconds = 0;

		foreach ($time_data as $span)
		{
			$time_diff = 0;

			if ($span['out'] == 0)
			{
				$out_time = time();
			}
			else
			{
				$out_time = $span['out'];
			}
			
			$time_diff = $out_time - $span['in'];
			$total_seconds += $time_diff;

			$time_diff_str = round($time_diff / 60 / 60, 3) . ' hours';
			
			$html .= sprintf("<tr><td>%s</td><td>%s</td><td>%s</td></tr>\n", date('m/d/Y h:i:s a', $span['in']), ($span['out'] != 0 ? date('m/d/Y h:i:s a', $span['out']) : ''), $time_diff_str);

		}

		$html .= sprintf("<tr><th colspan=\"2\">Total Time</th><th>%s hours</th></tr>\n", round($total_seconds / 60 / 60, 2));
		$html .= "</table>\n";
	}
	else
	{
		$html .= '<p>No data found for the current period.</p>';
	}

	return $html;
}

?>


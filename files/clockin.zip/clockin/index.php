<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
 <title>Clock In / Out</title>
 <link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<?php

include('db_connect.inc.php');
include('funcs.inc.php');

// :TODO: implement user login & set this up correctly
$_SESSION['uid'] = 0;

// Figure out the timestamp for the beginning of this week.
$date_array = getdate();

$week_start_str = '12 am ';

if ($date_array['wday'] == 0)
	$week_start_str .= 'today';
else
	$week_start_str .= 'last sunday';

$week_start_dt = strtotime($week_start_str);

// Calculate the timestamp for the end of this week.
$week_end_dt = $week_start_dt + (60 * 60 * 24 * 7) - 1;

// 
$active_record = get_active_record($_SESSION['uid']);

// Handle "Clock In" / "Clock Out" button click
if (isset($_POST['clock_in']))
{
	if (clock_in() === false)
	{
		print "<p>Unable to clock in.</p>\n";
	}

}
else if (isset($_POST['clock_out']))
{
	if (clock_out() === false)
	{
		print "<p>Unable to clock out.</p>\n";
	}
}

?>

<div id="controls">
	<form method="post">
		<?php
		if (is_clocked_in())
		{
			printf('<input type="hidden" name="time_id" value="%s">', $active_record['id']);
			print  '<input type="submit" name="clock_out" value="Clock Out">';
		}
		else
		{
			print '<input type="submit" name="clock_in" value="Clock In">';
		}
		?>
	</form>
</div>

<?php

// Print out the various time data
print "<div>\n";
print "<h3>Today</h3>\n";
print get_time_data_html(get_time_data(strtotime('12 am today'), 0, $_SESSION['uid']));
print "</div>\n";

print "<div>\n";
print "<h3>This Week</h3>\n";
print get_time_data_html(get_time_data($week_start_dt, 0, $_SESSION['uid']));
print "</div>\n";

print "<div>\n";
print "<h3>Older</h3>\n";
print get_time_data_html(get_time_data(0, $week_start_dt - 1, $_SESSION['uid']));
print "</div>\n";
?>
</body>
</html>
